package u6u7.entregable;

import u6u7.entregable.Artista.EstiloMusical;

public class Main {
	public static void main(String[] args) {
		
		//CREO FESTIVAL
		Festival fest = new Festival(41950,"Bombastic");
		
		//CREO A LOS MUSICOS
		Musico mus1 = new Musico("Dani",18);
		Musico mus2 = new Musico("Raul",19);
		Musico mus3 = new Musico("Pedro",20);
		Musico mus4 = new Musico("Marta",21);
		Musico mus5 = new Musico("Lucia",22);
		Musico mus6 = new Musico("David",23);
		
		//CREO A LOS MANAGERS
		Manager man1 = new Manager("Paco", 333444555);
		Manager man2 = new Manager("Carlos", 222333444);
		Manager man3 = new Manager("Lourdes", 123456789);
		Manager man4 = new Manager("Romero", 999111999);
		
		//CREO LOS GRUPOS
		Artista grup1 = new Artista("indie1",EstiloMusical.INDIE, 10000, man1);
		Artista grup2 = new Artista("indie2",EstiloMusical.INDIE, 20000, man2);
		Artista grup3 = new Artista("Pop1",EstiloMusical.POP, 30000, man3);
		Artista grup4 = new Artista("Pop2",EstiloMusical.POP, 40000, man4);
		
		//PRUEBO METODOS ARTISTAS
		
			//AÑADO A LOS MUSICOS A SUS GRUPOS
			grup1.addMusico(mus1);
			grup1.addMusico(mus2);
			grup2.addMusico(mus3);
			grup3.addMusico(mus4);
			grup3.addMusico(mus5);
			grup4.addMusico(mus6);
			
			//MUESTRO LOS GRUPOS
			System.out.println("-----------MUSICOS PRIMER GRUPO------------");
			grup1.imprimeMusicos();
			System.out.println("\n-----------MUSICOS SEGUNDO GRUPO------------");
			grup2.imprimeMusicos();
			System.out.println("\n-----------MUSICOS TERCER GRUPO------------");
			grup3.imprimeMusicos();
			System.out.println("\n-----------MUSICOS CUARTO GRUPO------------");
			grup4.imprimeMusicos();
			
			//PRUEBO EL METODO DELMUSICO
			System.out.println("\n-----------MUSICOS PRIMER GRUPO HABIENDO BORRADO A UNO------------");
			grup1.delMusico(mus1);
			grup1.imprimeMusicos();
			
			
		//PRUEBO METODOS FESTIVAL
			
			//METODO INSCRIBIR
				try {
					fest.inscribeArtista(EstiloMusical.INDIE, grup1);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					fest.inscribeArtista(EstiloMusical.INDIE, grup2);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					fest.inscribeArtista(EstiloMusical.POP, grup3);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					fest.inscribeArtista(EstiloMusical.POP, grup4);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//FUERZA EL ERROR
					/*try {
						fest.inscribeArtista(EstiloMusical.ROCK, grup4);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
				
				//PRUEBO METODO CUANTOSESCRITOS
				System.out.println("\n-----------NUMERO DE ARTISTAS INSCRITOS------------");
				System.out.println("[ El numero de Artistas/Grupos inscritos es: "+fest.cuantosInscritos()+" ]");
				
				//PRUEBO METODO ARTISTASBYCACHE
				System.out.println("\n-----------ARTISTAS DE UN ESTILO ORDENADOS POR CACHE------------");
				fest.artistasByCache(EstiloMusical.INDIE);
				
				//PRUEBO METODO ARTISTASINSCRITOS
				System.out.println("\n-----------ARTISTAS ORDENADOS POR NOMBRE------------");
				fest.artistasInscritos();
				
				//PRUEBLO LOS METODOS CON FICHEROS
				fest.guardarArtistas();
				fest.cargarArtistas();
				
				//NO ME FUNCIONAN POR LO DE SERIALIZABLE ( NO ME DA TIEMPO )
				
				
			
			
		
	}
}
