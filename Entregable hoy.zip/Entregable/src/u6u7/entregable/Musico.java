package u6u7.entregable;

import java.io.Serializable;

public class Musico implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 3L;


	@Override
	public String toString() {
		return "Musico [nombreArtistico=" + nombreArtistico + ", edad=" + edad + "]";
	}
	private String nombreArtistico;
	private int edad;
	
	
	public Musico(String nom, int edad) {
		this.edad = edad;
		this.nombreArtistico = nom;
	}
	
	
	
	public String getNombreArtistico() {
		return nombreArtistico;
	}
	public void setNombreArtistico(String nombreArtistico) {
		this.nombreArtistico = nombreArtistico;
	}
	public int getEdad() {
		return edad;
	}
	public void setEdad(int edad) {
		this.edad = edad;
	}
}
