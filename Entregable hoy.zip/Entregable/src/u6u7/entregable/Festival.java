package u6u7.entregable;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import u6u7.entregable.Artista.EstiloMusical;

public class Festival implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	protected String nombre;
	protected int codigoPostal;
	protected Map<EstiloMusical , Set<Artista>> mapaArtistas;
	public static int contadorArtistas;
	
	
	public Festival(int cd, String nombre) {
		this.codigoPostal = cd;
		this.nombre = nombre;
		this.mapaArtistas = new HashMap<>();
		this.mapaArtistas.put(EstiloMusical.INDIE ,new TreeSet<>());
		this.mapaArtistas.put(EstiloMusical.POP,new TreeSet<>());
		this.mapaArtistas.put(EstiloMusical.ROCK ,new TreeSet<>());
	}
	
	public void inscribeArtista(EstiloMusical estilo , Artista artista) throws Exception {
		if (estilo != artista.estilo) {//COMPRUEBO QUE EL ESTILO SEA EL INDICADO AL CREAR AL ARTISTA
			throw new Exception("El Artista no pertenece a ese estilo.");
		}
		else {
			this.mapaArtistas.get(estilo).add(artista);
			contadorArtistas++;	
		}
	}
	
	public static int cuantosInscritos() {
		return contadorArtistas;
	}
	
	public void artistasByCache(EstiloMusical estilo) {
		Set<Artista> aux = mapaArtistas.get(estilo);
		List<Artista> ListaOrdenada = new ArrayList<>(aux);
		Collections.sort(ListaOrdenada,new ComparadorCache());
			System.out.println(ListaOrdenada);
	}
	
	public void artistasInscritos() {
		System.out.println("\n----ARTISTAS DE INDIE------");
		System.out.println(mapaArtistas.get(EstiloMusical.INDIE));
		System.out.println("\n----ARTISTAS DE ROCK------");
		System.out.println(mapaArtistas.get(EstiloMusical.ROCK));
		System.out.println("\n----ARTISTAS DE POP------");
		System.out.println(mapaArtistas.get(EstiloMusical.POP));
	}
	
	public void guardarArtistas() {
		try(ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("artistas.dat"))){
			oos.writeObject(mapaArtistas);
			oos.flush();
			

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void cargarArtistas()  {
		try(ObjectInputStream ois = new ObjectInputStream(new FileInputStream("artistas.dat"))){
			mapaArtistas = (Map<EstiloMusical, Set<Artista>>) ois.readObject();		
			System.out.println(mapaArtistas);
			ois.close();
		
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
}
