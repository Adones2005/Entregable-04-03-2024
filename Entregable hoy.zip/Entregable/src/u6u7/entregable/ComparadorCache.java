package u6u7.entregable;

import java.util.Comparator;

public class ComparadorCache implements Comparator<Artista> {
	@Override
	public int compare(Artista o1, Artista o2) {
		return o2.cache - o1.cache;
	}

}
