package u6u7.entregable;

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class Artista implements Comparable<Artista> , Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;


	@Override
	public String toString() {
		return "Artista [nombre=" + nombre + ", estilo=" + estilo + ", cache=" + cache + "]";
	}

	protected String nombre;
	protected enum EstiloMusical{POP,ROCK,INDIE};
	protected EstiloMusical estilo;
	protected int cache;
	protected Manager manager;
	protected Set<Musico> musicos;
	
	
	public Artista(String nombre, EstiloMusical estilo, int cache, Manager manager) {
		this.cache = cache;
		this.manager = manager;
		this.nombre = nombre;
		this.estilo = estilo;
		this.musicos = new LinkedHashSet<>();
	}
	
	public void addMusico(Musico musico) {
		this.musicos.add(musico);
	}
	
	public void delMusico(Musico musico) {
		this.musicos.remove(musico);
	}
	
	//ITERO POR EL SET Y MUESTRO OBJETO A OBJETO
	public void imprimeMusicos() {
		Iterator<Musico> it = musicos.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

	@Override
	public int compareTo(Artista o) {
		return this.nombre.compareTo(o.nombre);
	}
	
}
