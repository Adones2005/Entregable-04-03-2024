package u6u7.entregable;

public class Manager {

	private String nombre;
	private int numTelef;
	
	public Manager(String nombre, int numTelef) {
		this.nombre = nombre;
		this.numTelef = numTelef;
	}

	public int getNumTelef() {
		return numTelef;
	}

	public void setNumTelef(int numTelef) {
		this.numTelef = numTelef;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
}
